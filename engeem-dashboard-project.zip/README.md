# ENGEEM Dashboard

A real-time data stream monitoring dashboard built with Next.js, Tailwind CSS, and Recharts. Designed from Figma and fully responsive for desktop, tablet, and mobile.

## Features

- **Data Stream Status** — Real-time metrics overview with Total Stats, Avg Rows/Sec, Peak Mbps, CPU Usage
- **Stats Timeline** — Area chart showing performance metrics over time
- **Top 10 Processes** — Horizontal bar chart of most active processes
- **Throughput Timeline** — Dual-axis area chart for Row/Sec and Mbps
- **Resources Timeline** — Line chart for CPU and Memory usage
- **Responsive Design** — Sidebar drawer on mobile, scrollable tabs, adaptive grid layouts

## Tech Stack

- **Next.js 14** — React framework with App Router
- **TypeScript** — Type-safe development
- **Tailwind CSS 3** — Utility-first styling
- **Recharts** — Composable charting library
- **Lucide React** — Beautiful icon library

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

Open [http://localhost:3000](http://localhost:3000) to view the dashboard.

## Project Structure

```
src/
├── app/
│   ├── globals.css       # Global styles + Tailwind
│   ├── layout.tsx        # Root layout
│   └── page.tsx          # Home page
├── components/
│   ├── Dashboard.tsx     # Main dashboard component
│   ├── Sidebar.tsx       # Navigation sidebar
│   ├── Header.tsx        # Breadcrumb, tabs, status bar
│   ├── MetricCards.tsx   # KPI metric cards
│   ├── Charts.tsx        # All chart components
│   └── hooks/
│       └── useMediaQuery.ts  # Responsive hook
└── data/
    └── mockData.ts       # Sample data
```

## Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/engeem-dashboard)

## License

MIT
